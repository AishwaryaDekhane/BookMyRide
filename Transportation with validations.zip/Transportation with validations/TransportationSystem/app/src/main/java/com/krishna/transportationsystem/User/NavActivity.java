package com.krishna.transportationsystem.User;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.krishna.transportationsystem.User.PaymentActivity.MY_PREFS_NAME;

public class NavActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private Button mBtnFindPath,mBtnConfirmedRide;
    private EditText editTextOrigin;
    private EditText editTextDestination;
    private TextView txtCost;
    private BottomNavigationView mMainNav,mMainCar,mMainBus,mMainBike,mMainTruck;
    RelativeLayout mRelativeCarType,mRelativeBusType,
            mRelativeBikeType,mRelativeTruckType;
    String pick_up;
    String destinaton;
    String ride;
    String payment;
    TextView txtPick,txtDest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nav);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (!SharedPrefManager.getInstance(this).isLoggedIn()){

            finish();
            startActivity(new Intent(this, LoginActivity.class));
            return;
        }


        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }
        mBtnFindPath = findViewById(R.id.btnRequest);
        mBtnConfirmedRide=findViewById(R.id.btnShowConfirmedRide);
        editTextOrigin = findViewById(R.id.editTextOrigin);
        editTextDestination =findViewById(R.id.editTextDestination);
        txtCost=findViewById(R.id.txtCost);
        txtPick=findViewById(R.id.txtPickUp1);
        txtDest=findViewById(R.id.txtDest);
        mMainNav= findViewById(R.id.main_nav);
        mMainCar=findViewById(R.id.main_nav_car);
        mMainBike=findViewById(R.id.main_nav_bike);
        mMainBus=findViewById(R.id.main_nav_bus);
        mMainTruck=findViewById(R.id.main_nav_truck);
        mRelativeCarType=findViewById(R.id.relLayoutCarType);
        mRelativeBusType=findViewById(R.id.relLayoutBusType);
        mRelativeBikeType=findViewById(R.id.relLayoutBikeType);
        mRelativeTruckType=findViewById(R.id.relLayoutTruckType);


        payment= getIntent().getStringExtra("cash");
        /*SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String restoredText = prefs.getString("text", null);
        if (restoredText != null) {
            payment1 = prefs.getString("name", payment);//"No name defined" is the default value.

        }
*/



        mMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_car:
                        mRelativeCarType.setVisibility(View.VISIBLE);
                        mRelativeBusType.setVisibility(View.GONE);
                        mRelativeBikeType.setVisibility(View.GONE);
                        mRelativeTruckType.setVisibility(View.GONE);


                        return true;
                    case R.id.menu_bus:
                        mRelativeCarType.setVisibility(View.GONE);
                        mRelativeBusType.setVisibility(View.VISIBLE);
                        mRelativeBikeType.setVisibility(View.GONE);
                        mRelativeTruckType.setVisibility(View.GONE);



                        return true;
                    case R.id.menu_bike:
                        mRelativeCarType.setVisibility(View.GONE);
                        mRelativeBusType.setVisibility(View.GONE);
                        mRelativeBikeType.setVisibility(View.VISIBLE);
                        mRelativeTruckType.setVisibility(View.GONE);

                        return true;
                    case R.id.menu_truck:
                        mRelativeCarType.setVisibility(View.GONE);
                        mRelativeBusType.setVisibility(View.GONE);
                        mRelativeBikeType.setVisibility(View.GONE);
                        mRelativeTruckType.setVisibility(View.VISIBLE);

                        return true;

                    default:
                        return false;

                }
            }
        });

        mMainCar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_car_4_sit:


                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("99");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"99", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("55");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"55", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("200");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"200", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="car 4 seater";

                        return true;
                    case R.id.menu_car_6_sit:
                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("120");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"120", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("88");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"88", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("300");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"300", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }

                        ride="car 6 seater";

                        return true;
                    case R.id.menu_car_12_sit:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("150");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"150", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("100");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"100", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("400");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"400", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }

                        ride="car 12 seater";

                        return true;

                    default:
                        return false;

                }
            }
        });
        mMainBike.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_bike:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("120");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"120", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("70");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"70", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("200");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"200", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="bike";

                        return true;
                    case R.id.menu_auto:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("60");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"60", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("180");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"180", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("120");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"200", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="auto";

                        return true;
                    case R.id.menu_mini_truck:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("999");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"999", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("555");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"555", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("2200");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"2200", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="mini truck";

                        return true;

                    default:
                        return false;

                }
            }
        });

        mMainBus.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_bus_20_seat:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("250");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"250", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("230");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"230", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("280");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"280", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="bus 20 seater";

                        return true;
                    case R.id.menu_mini_bus:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("277");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"277", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("237");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"237", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("427");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"427", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="mini bus";

                        return true;
                    case R.id.menu_bus_50_seat:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("500");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"500", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("600");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"600", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("788");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"788", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="bus 50 seater";

                        return true;

                    default:
                        return false;

                }
            }
        });

        mMainTruck.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_small_truck:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("678");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"678", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("647");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"647", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("768");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"768", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="small transportaion";

                        return true;
                    case R.id.menu_medium_truck:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("879");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"879", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("980");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"980", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("1209");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"1209", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="medium transportaion";

                        return true;
                    case R.id.menu_large_truck:

                        if (editTextOrigin.getText().toString().equals("Shivajinagar") &&
                                editTextDestination.getText().toString().equals("JM Road")){
                            txtCost.setText("1200");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"1200", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else if (editTextOrigin.getText().toString().equals("Swargate") &&
                                editTextDestination.getText().toString().equals("Tilak Road")){
                            txtCost.setText("1100");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"1100", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }else{
                            txtCost.setText("1280");
                            Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"1280", Snackbar.LENGTH_LONG)
                                    .setAction("Action", null).show();
                        }
                        ride="large transportaion";

                        return true;

                    default:
                        return false;

                }
            }
        });

        mBtnFindPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editTextOrigin.getText().toString().equals("") ||
                        editTextOrigin.getText().toString().equals("")  ) {
                    Toast.makeText(NavActivity.this, "Please enter full details", Toast.LENGTH_SHORT).show();
                    return;
                }
                sendRequest(ride,payment);
                sendBookRequest(ride,payment);


            }
        });

        getConfirmed();

        mBtnConfirmedRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MapsActivity.class);

                intent.putExtra("pick_up", txtPick.getText().toString());
                intent.putExtra("destination", txtDest.getText().toString());
                startActivity(intent);
                finish();
                deleteRide();
                generateotp();

            }
        });


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View header=navigationView.getHeaderView(0);
        TextView mTxtName = header.findViewById(R.id.navHeaderName);
        TextView mTxtEmail = header.findViewById(R.id.navHeaderEmail);


        final String name= SharedPrefManager.getInstance(NavActivity.this).getUserName();
        final String email= SharedPrefManager.getInstance(NavActivity.this).getUserEmail();

        mTxtName.setText(name);
        mTxtEmail.setText(email);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.nav, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_your_trips) {
           startActivity(new Intent(NavActivity.this,UserHistoryActivity.class));
        } else if (id == R.id.nav_help) {
           startActivity(new Intent(NavActivity.this,HelpActivity.class));
        } else if (id == R.id.nav_payment) {

            startActivity(new Intent(NavActivity.this,PaymentActivity.class));
        } else if (id == R.id.nav_logout) {
            SharedPrefManager.getInstance(this).logout();
            finish();
            startActivity(new Intent(this,LoginActivity.class));
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void getConfirmed(){
        final String user_email= SharedPrefManager.getInstance(NavActivity.this).getUserEmail();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, IPConfig.GET_CONFIRMED_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {

                                pick_up= obj.getString("pick_up");
                                destinaton=obj.getString("dest_point");
                                txtPick.setText(pick_up);
                                txtDest.setText(destinaton);

                                Toast.makeText(
                                        getApplicationContext(),
                                        "Pick up: "+pick_up+"\n"+"Destination point: "+destinaton,
                                        Toast.LENGTH_LONG
                                ).show();
                                mBtnConfirmedRide.setVisibility(View.VISIBLE);
                                if (pick_up.equals("null")){
                                    mBtnConfirmedRide.setVisibility(View.GONE);
                                }
                            } else {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                                mBtnConfirmedRide.setVisibility(View.GONE);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(
                        getApplicationContext(),
                        error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_email",user_email);
                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(NavActivity.this);
        requestQueue.add(stringRequest);
    }

    public void deleteRide(){
        final String user_email= SharedPrefManager.getInstance(NavActivity.this).getUserEmail();

        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                IPConfig.DELETE_RIDE_URL+user_email,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(NavActivity.this, response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NavActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {

                return new HashMap<>();
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(NavActivity.this);
        requestQueue.add(stringRequest);

    }

    public void generateotp(){

        final String user_email= SharedPrefManager.getInstance(NavActivity.this).getUserEmail();
        RequestQueue queue = Volley.newRequestQueue(NavActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, IPConfig.GENERATE_OTP_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Toast.makeText(NavActivity.this,response,Toast.LENGTH_SHORT).show();

                /*if (response.contains("Success")){

                    Toast.makeText(NavActivity.this,"request sent",Toast.LENGTH_SHORT).show();
                }*/
                Log.i("My success",""+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(NavActivity.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {

                Map<String,String> map = new HashMap<>();

                map.put("user_email",user_email);
                map.put("note","OTP successfully matched");

                return map;
            }
        };
        queue.add(request);
    }

    public void sendRequest(final String vehicle,final String payment) {

        final String pick_up=editTextOrigin.getText().toString();
        final String dest_point=editTextDestination.getText().toString();
        final String cost=txtCost.getText().toString();

        final String user_email= SharedPrefManager.getInstance(NavActivity.this).getUserEmail();
        RequestQueue queue = Volley.newRequestQueue(NavActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, IPConfig.BOOK_REQUEST_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                if (response != null)
                Toast.makeText(NavActivity.this,response,Toast.LENGTH_SHORT).show();

                /*if (response.contains("Success")){

                    Toast.makeText(NavActivity.this,"request sent",Toast.LENGTH_SHORT).show();
                }*/
                Log.i("My success",""+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(NavActivity.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {

                Map<String,String> map = new HashMap<>();

                map.put("user_email",user_email);
                map.put("pick_up",pick_up);
                map.put("dest_point",dest_point);
                map.put("vehicle_type",vehicle);
                map.put("payment",payment);
                map.put("cost",cost);


                return map;
            }
        };
        queue.add(request);
    }

    public void sendBookRequest(final String vehicle,final String payment) {

        final String pick_up=editTextOrigin.getText().toString();
        final String dest_point=editTextDestination.getText().toString();
        final String cost=txtCost.getText().toString();

        final String user_email= SharedPrefManager.getInstance(NavActivity.this).getUserEmail();
        RequestQueue queue = Volley.newRequestQueue(NavActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, IPConfig.SEND_BOOK_REQUEST_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {


                Toast.makeText(NavActivity.this,response,Toast.LENGTH_SHORT).show();

                /*if (response.contains("Success")){

                    Toast.makeText(NavActivity.this,"request sent",Toast.LENGTH_SHORT).show();
                }
                Log.i("My success",""+response);
*/
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(NavActivity.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {

                Map<String,String> map = new HashMap<>();

                map.put("user_name",user_email);
                map.put("pick",pick_up);
                map.put("dest",dest_point);
                map.put("cost",cost);
                map.put("vehicle_typ",vehicle);
                //map.put("payment",payment);


                return map;
            }
        };
        queue.add(request);
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        /*switch(view.getId()) {
            case R.id.radio_card:
                if (checked)
                    payment="card";
                final FragmentManager fm=getSupportFragmentManager();
                final ItemFragment itemFragment=new ItemFragment();

                //Pass area name and table no to next menuFragment
                Bundle bundle = new Bundle();

                itemFragment.setArguments(bundle);

                itemFragment.show(fm,"Item");
                Toast.makeText(NavActivity.this,"card",Toast.LENGTH_LONG).show();
                break;
            case R.id.radio_cash:
                if (checked)
                    payment="cash";
                Toast.makeText(NavActivity.this,"cash",Toast.LENGTH_LONG).show();

                break;*/
        //}

    }
}
