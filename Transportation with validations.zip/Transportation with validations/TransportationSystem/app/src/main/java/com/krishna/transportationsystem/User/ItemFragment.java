package com.krishna.transportationsystem.User;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import com.krishna.transportationsystem.R;



public class ItemFragment extends DialogFragment {

    private EditText mEdtAccountNo,mEdtAddcvv;
    private Button mBtnDoneDialog;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.item_fragment,container);

        mEdtAccountNo=view.findViewById(R.id.edtAccountNo);
        mEdtAddcvv=view.findViewById(R.id.edtAddcvv);
        mBtnDoneDialog=view.findViewById(R.id.btnDoneDialog);

        mBtnDoneDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              dismiss();
            }
        });


        return view;
    }

    /*private void sendOrder() {
        final String name=mTxtName.getText().toString().trim();
        final String qty=mTxtQty.getText().toString().trim();
        final String cost=mTxtCost.getText().toString().trim();
        final String require_qty=mEdtAddQty.getText().toString().trim();
        final String accept_cost=mEdtAddCost.getText().toString().trim();
        final String restaurant_name= SharedPrefManager.getInstance(getActivity()).getUserName();


        progressDialog.setMessage("Uploading data...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                Functions.SEND_ORDER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        Toast.makeText(getContext(), response, Toast.LENGTH_LONG).show();
                        mEdtAddCost.setText(null);
                        mEdtAddQty.setText(null);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.hide();
                        Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                params.put("restaurant_name", restaurant_name);
                params.put("order_name", name);
                params.put("order_qty", qty);
                params.put("order_cost",cost);
                params.put("require_qty", require_qty);
                params.put("accept_cost",accept_cost);


                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);


    }*/





}
