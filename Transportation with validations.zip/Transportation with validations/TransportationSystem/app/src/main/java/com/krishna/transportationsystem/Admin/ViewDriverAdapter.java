package com.krishna.transportationsystem.Admin;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;

import java.util.ArrayList;

class ViewDriverAdapter extends RecyclerView.Adapter<ViewDriverAdapter.DriverViewHolder> {

    private Context mContext;
    private ArrayList<ModelClass> mListDriver;

    public ViewDriverAdapter(Context mContext, ArrayList<ModelClass> mListDriver) {
        this.mContext = mContext;
        this.mListDriver = mListDriver;
    }

    @NonNull
    @Override
    public DriverViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.adapter_view_driver, viewGroup, false);

        return new DriverViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DriverViewHolder holder, int position) {

        holder.mTxtDriverId.setText(mListDriver.get(position).getDriverId());
        holder.mTxtDriverName.setText(mListDriver.get(position).getDriverName());
        holder.mTxtDriverEmail.setText(mListDriver.get(position).getDriverEmail());
        holder.mTxtDriverMobile.setText(mListDriver.get(position).getDriverMobile());
        holder.mTxtDriverLicense.setText(mListDriver.get(position).getDriverLicence());
        holder.mTxtDriverAadhar.setText(mListDriver.get(position).getDriverAadhar());
        holder.mTxtAccepted.setText(mListDriver.get(position).getAccepted());

        if (holder.mTxtAccepted.getText().toString().equals("Accepted")){
            holder.mBtnAccept.setVisibility(View.GONE);
            holder.mTxtAccepted.setVisibility(View.VISIBLE);
        }else {
            holder.mBtnAccept.setVisibility(View.VISIBLE);
            holder.mTxtAccepted.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mListDriver.size();
    }

    public class DriverViewHolder extends RecyclerView.ViewHolder {
        private TextView mTxtDriverId,mTxtDriverName,mTxtDriverEmail,mTxtDriverMobile,mTxtDriverLicense,
                mTxtDriverAadhar,mTxtAccepted;
        private Button mBtnAccept;

        public DriverViewHolder(@NonNull View itemView) {
            super(itemView);

            mTxtDriverId=itemView.findViewById(R.id.txtDriverId);
            mTxtDriverName=itemView.findViewById(R.id.txtDriverName);
            mTxtDriverEmail=itemView.findViewById(R.id.txtDriverEmailId);
            mTxtDriverMobile=itemView.findViewById(R.id.txtDriverMobile);
            mTxtDriverLicense=itemView.findViewById(R.id.txtDriverLicNo);
            mTxtDriverAadhar=itemView.findViewById(R.id.txtDriverAadhar);
            mBtnAccept=itemView.findViewById(R.id.btnAccept);
            mTxtAccepted=itemView.findViewById(R.id.txtAccepted);

            mBtnAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ModelClass modelClass=mListDriver.get(getAdapterPosition());
                    mClickListener.onAcceptClick(modelClass);
                }
            });

        }
    }

    public interface AcceptClickListener {
        void onAcceptClick(ModelClass modelClass);
    }
    private AcceptClickListener mClickListener;

    public void setAcceptClickListener(AcceptClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

}