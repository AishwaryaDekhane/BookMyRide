package com.krishna.transportationsystem.Admin;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class HelpRequestActivity extends AppCompatActivity {

    private ArrayList<ModelClass> mListNotifications;
    RecyclerView recyclerView;
    private RequestQueue requestQueue;
    HelpRequestAdapter adapter;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_request);
        recyclerView = findViewById(R.id.recyclerHelpRequest);
        mListNotifications = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(HelpRequestActivity.this);
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                IPConfig.GET_HELP_URL, null, new SuccessListener(),
                new FailureListener());

        requestQueue.add(jsonObjectRequest);
        progressDialog =new ProgressDialog(HelpRequestActivity.this);
    }

    class SuccessListener implements Response.Listener<JSONObject>{

        @Override
        public void onResponse(JSONObject response) {

            Log.e("Response", "data:" + response.toString());

            try {

                JSONArray jsonOrders = (JSONArray) response.get("result");
                for (int i = 0; i < jsonOrders.length(); i++)

                {
                    ModelClass modelClass = new ModelClass();
                    JSONObject jsonObject1 = jsonOrders.getJSONObject(i);

                    String username=jsonObject1.getString("user_name");
                    String topic=jsonObject1.getString("topic");
                    String help=jsonObject1.getString("help");

                    modelClass.setHelp("Customer Name:"+username+"\nHelp Related: " +topic+
                            "\nHelp details: "+help);

                    mListNotifications.add(modelClass);

                }

                adapter = new HelpRequestAdapter(HelpRequestActivity.this, mListNotifications);
                recyclerView.setLayoutManager(new LinearLayoutManager(HelpRequestActivity.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            adapter.notifyDataSetChanged();

        }

    }
    class FailureListener implements Response.ErrorListener {

        @Override
        public void onErrorResponse(VolleyError error) {
            Log.e("error",error.toString());
        }
    }
}
