package com.krishna.transportationsystem.Driver;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DriverActivity extends AppCompatActivity {

    private ArrayList<ModelClass> mListUser;
    RecyclerView recyclerView;
    private RequestQueue requestQueue;
    UserRequestAdapter adapter;
    ProgressDialog progressDialog;
    String requestId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver);

        if (!SharedPrefManager.getInstance(this).isDriverLoggedIn()){

            finish();
            startActivity(new Intent(this, DriverLoginActivity.class));
        }
        recyclerView = findViewById(R.id.recyclerUserRequestList);
        mListUser = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(DriverActivity.this);
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                IPConfig.GET_USER_REQUEST_URL, null, new SuccessListener(),
                new FailureListener());

        requestQueue.add(jsonObjectRequest);
        progressDialog =new ProgressDialog(DriverActivity.this);

    }
    class SuccessListener implements Response.Listener<JSONObject>{

        @Override
        public void onResponse(JSONObject response) {

            Log.e("Response", "data:" + response.toString());

            try {

                JSONArray jsonOrders = (JSONArray) response.get("result");
                for (int i = 0; i < jsonOrders.length(); i++)

                {
                    ModelClass modelClass = new ModelClass();
                    JSONObject jsonObject1 = jsonOrders.getJSONObject(i);
                    requestId=jsonObject1.getString("flag");
                    modelClass.setRequestId(jsonObject1.getString("id"));
                    modelClass.setUserEmail(jsonObject1.getString("user_email"));
                    modelClass.setPickup(jsonObject1.getString("pick_up"));
                    modelClass.setDestinationPoint(jsonObject1.getString("dest_point"));
                    modelClass.setVehicleType(jsonObject1.getString("vehicle_type"));
                    modelClass.setPayment(jsonObject1.getString("payment"));
                    modelClass.setCost(jsonObject1.getString("cost"));

                    if (requestId.equals("1")) {
                        modelClass.setConfirmed("Confirmed");
                    }
                    mListUser.add(modelClass);

                }

                adapter = new UserRequestAdapter(DriverActivity.this, mListUser);
                adapter.setAcceptClickListener(new MyAcceptBtnListener());
                recyclerView.setLayoutManager(new LinearLayoutManager(DriverActivity.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            adapter.notifyDataSetChanged();

        }

    }
    class FailureListener implements Response.ErrorListener {

        @Override
        public void onErrorResponse(VolleyError error) {
            Log.e("error",error.toString());
        }
    }

    class MyAcceptBtnListener implements UserRequestAdapter.AcceptClickListener{

        @Override
        public void onAcceptClick(ModelClass modelClass) {
            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    IPConfig.USER_REQUEST_ACCEPT_URL+modelClass.getRequestId(),
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Toast.makeText(DriverActivity.this, response, Toast.LENGTH_LONG).show();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(DriverActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();

                    params.put("flag", "1");


                    return params;
                }
            };
            RequestQueue requestQueue=Volley.newRequestQueue(DriverActivity.this);
            requestQueue.add(stringRequest);

        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.menu_logout) {
            SharedPrefManager.getInstance(this).driverLogout();
            finish();
            startActivity(new Intent(this,DriverLoginActivity.class));
            return true;
        }else if (id == R.id.menu_match_otp) {
            final FragmentManager fm=getSupportFragmentManager();
            final OTPMatchedFragment otpMatchedFragment=new OTPMatchedFragment();

            otpMatchedFragment.show(fm,"Item");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
