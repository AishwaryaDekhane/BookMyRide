package com.krishna.transportationsystem.User;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.krishna.transportationsystem.R;

public class HelpActivity extends AppCompatActivity {

    private TextView mTxtTrips,mTxtAcc,mTxtGuide,mTxtMore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        mTxtTrips=findViewById(R.id.txtTripIssue);
        mTxtAcc=findViewById(R.id.txtAccount);
        mTxtGuide=findViewById(R.id.txtGuide);
        mTxtMore=findViewById(R.id.txtMore);

        mTxtTrips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), SendHelpActivity.class);
                intent.putExtra("Trips", mTxtTrips.getText().toString());
                startActivity(intent);
            }
        });
        mTxtAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), SendHelpActivity.class);
                intent.putExtra("Trips", mTxtAcc.getText().toString());
                startActivity(intent);
            }
        });
        mTxtGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), SendHelpActivity.class);
                intent.putExtra("Trips", mTxtGuide.getText().toString());
                startActivity(intent);
            }
        });
        mTxtMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), SendHelpActivity.class);
                intent.putExtra("Trips", mTxtMore.getText().toString());
                startActivity(intent);
            }
        });
    }
}
