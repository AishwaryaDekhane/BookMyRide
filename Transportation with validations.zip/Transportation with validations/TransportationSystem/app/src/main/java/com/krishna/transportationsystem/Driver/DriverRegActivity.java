package com.krishna.transportationsystem.Driver;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.User.LoginActivity;
import com.krishna.transportationsystem.User.RegistrationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DriverRegActivity extends AppCompatActivity {

    private EditText mEdtName,mEdtEmail,mEdtMobile,mEdtAddess,mEdtPassword,
            mEdtDrivingLic,mEdtAadhar;
    private Button mBtnSignUp;
    ProgressDialog progressDialog;
    private AwesomeValidation awesomeValidation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_reg);
        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        init();
    }

    private void init() {
        mEdtName=findViewById(R.id.edtDriverRegName);
        mEdtEmail=findViewById(R.id.edtDriverRegEmail);
        mEdtMobile=findViewById(R.id.edtDriverRegMobile);
        mEdtAddess=findViewById(R.id.edtDriverRegArea);
        mEdtPassword=findViewById(R.id.edtDriverRegPassword);
        mEdtDrivingLic=findViewById(R.id.edtRegisterDrivingLic);
        mEdtAadhar=findViewById(R.id.edtRegisterAadharNo);

        mBtnSignUp=findViewById(R.id.btnSignUpDriver);
        addValidationToViews();

        progressDialog=new ProgressDialog(this);

        mBtnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*if (mEdtName.toString().equals("")||mEdtEmail.getText().toString().equals("")
                        || mEdtMobile.getText().toString().equals("")
                        || mEdtAddess.getText().toString().equals("")
                        || mEdtPassword.getText().toString().equals("") ) {
                    Toast.makeText(DriverRegActivity.this, "Please enter full details", Toast.LENGTH_SHORT).show();
                    return;
                }
                registerUser();*/
                if (awesomeValidation.validate()) {
                    // Here, we are sure that form is successfully validated. So, do your stuffs now...
                    registerUser();
                }
            }
        });
    }
    private void addValidationToViews()
    {

        awesomeValidation.addValidation(this, R.id.edtDriverRegName, RegexTemplate.NOT_EMPTY, R.string.invalid_name);

        awesomeValidation.addValidation(this, R.id.edtDriverRegEmail, Patterns.EMAIL_ADDRESS, R.string.invalid_email);

        String regexPassword = ".{6,}";
        awesomeValidation.addValidation(this, R.id.edtDriverRegPassword, regexPassword, R.string.invalid_password);

        awesomeValidation.addValidation(this, R.id.edtDriverRegMobile, "^[+]?[0-9]{10,13}$", R.string.invalid_phone);
    }

    public void registerUser(){
        final String email=mEdtEmail.getText().toString().trim();
        final String name=mEdtName.getText().toString().trim();
        final String mobile=mEdtMobile.getText().toString().trim();
        final String password=mEdtPassword.getText().toString().trim();
        final String area=mEdtAddess.getText().toString().trim();
        final String driving_lic=mEdtDrivingLic.getText().toString().trim();
        final String aadhar=mEdtAadhar.getText().toString().trim();

        progressDialog.setMessage("Registering user...");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                IPConfig.DRIVER_REGISTER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            if (response.contains("success")){
                                Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();
                                startActivity(new Intent(DriverRegActivity.this,DriverLoginActivity.class));
                                finish();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.hide();
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", name);
                params.put("email", email);
                params.put("password", password);
                params.put("mobile", mobile);
                params.put("area", area);
                params.put("driving_lic", driving_lic);
                params.put("aadhar", aadhar);

                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(DriverRegActivity.this);
        requestQueue.add(stringRequest);


    }
}
