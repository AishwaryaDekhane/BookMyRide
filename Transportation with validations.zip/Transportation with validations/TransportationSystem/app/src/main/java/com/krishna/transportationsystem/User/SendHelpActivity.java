package com.krishna.transportationsystem.User;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;

import java.util.HashMap;
import java.util.Map;

public class SendHelpActivity extends AppCompatActivity {

    private TextView mTxtTopics;
    private EditText mEdtHelp;
    private Button mBtnHelp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_help);

        mTxtTopics=findViewById(R.id.txtTopics);
        mEdtHelp=findViewById(R.id.edtHelp);
        mBtnHelp=findViewById(R.id.btnHelp);
        String trips= getIntent().getStringExtra("Trips");
        mTxtTopics.setText(trips);
        mBtnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getHelp();
            }
        });
    }

    public void getHelp() {

        final String user_email= SharedPrefManager.getInstance(SendHelpActivity.this).getUserName();
        final String topic=mTxtTopics.getText().toString().trim();
        final String help=mEdtHelp.getText().toString();
        RequestQueue queue = Volley.newRequestQueue(SendHelpActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, IPConfig.SEND_HELP_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                Toast.makeText(SendHelpActivity.this,response,Toast.LENGTH_SHORT).show();

                if (response.contains("Success")){

                    Toast.makeText(SendHelpActivity.this,"help sent",Toast.LENGTH_SHORT).show();
                }
                Log.i("My success",""+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(SendHelpActivity.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {

                Map<String,String> map = new HashMap<>();

                map.put("user_name",user_email);
                map.put("topic",topic);
                map.put("help",help);
                //map.put("payment",payment);


                return map;
            }
        };
        queue.add(request);
    }

}
