package com.krishna.transportationsystem.User;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.krishna.transportationsystem.ChooseLanguageActivity;
import com.krishna.transportationsystem.R;

public class SplashActivity extends AppCompatActivity {
    private int SPLASH_TIME = 3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        Thread timer = new Thread() {
            public void run() {
                try {
                    sleep(SPLASH_TIME);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    /*if (SharedPref.getPrefForLoginStatus(SplashActivity.this)) {

                      //  ProjectUtils.genericIntent(SplashActivity.this, HomeActivity.class, null, true);
                    } else {*/
                        startActivity(new Intent(SplashActivity.this,LoginActivity.class));
                        finish();
                }
            }
        };
        timer.start();

    }
}
