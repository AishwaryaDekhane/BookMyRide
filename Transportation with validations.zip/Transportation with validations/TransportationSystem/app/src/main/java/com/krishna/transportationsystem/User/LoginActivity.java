package com.krishna.transportationsystem.User;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.Admin.AdminActivity;
import com.krishna.transportationsystem.ChooseLanguageActivity;
import com.krishna.transportationsystem.Driver.DriverLoginActivity;
import com.krishna.transportationsystem.Driver.DriverRegActivity;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText mEdtUsername,mEdtPassword;
    private Button mBtnSignIn,mBtnSignUp,mBtnAdmin,mBtnChooseLang;
    private TextView mTxtDriverReg;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadloccale();
        setContentView(R.layout.activity_login);

        init();
      /*  ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.app_name));
*/
        if (SharedPrefManager.getInstance(this).isLoggedIn()){

            finish();
            startActivity(new Intent(this, NavActivity.class));
            return;
        }

        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }

        if (SharedPrefManager.getInstance(this).isLoggedIn()){

            finish();
            startActivity(new Intent(this, NavActivity.class));
            return;
        }
        /*new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mTxtlanguage.performClick();
            }
        }, 500);
*/

    }

    private void init() {
        mEdtUsername=findViewById(R.id.edtEmail);
        mEdtPassword=findViewById(R.id.edtPassword);
        mBtnSignIn=findViewById(R.id.btnSignIn);
        mBtnAdmin=findViewById(R.id.btnadmin);
        mBtnSignUp=findViewById(R.id.btnSignUp);
        mTxtDriverReg=findViewById(R.id.txtDriverReg);
        mBtnChooseLang=findViewById(R.id.btnChooseLang);

        mBtnSignUp.setOnClickListener(this);
        mBtnSignIn.setOnClickListener(this);
        mTxtDriverReg.setOnClickListener(this);
        mBtnAdmin.setOnClickListener(this);
        mBtnChooseLang.setOnClickListener(this);


        progressDialog=new ProgressDialog(LoginActivity.this);

    }

    private void userLogin() {

        final String email = mEdtUsername.getText().toString().trim();
        final String password = mEdtPassword.getText().toString().trim();

        progressDialog.show();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, IPConfig.LOGIN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {
                                SharedPrefManager.getInstance(getApplicationContext()).
                                        userLogin(
                                                obj.getString("user_id"),
                                                obj.getString("name"),
                                                obj.getString("email")
                                        );
                                startActivity(new Intent(getApplicationContext(), NavActivity.class));
                                finish();
                            } else {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
                Toast.makeText(
                        getApplicationContext(),
                        error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);

                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(LoginActivity.this);
        requestQueue.add(stringRequest);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSignIn:
                if (mEdtUsername.toString().equals("") ||
                        mEdtPassword.toString().equals("")) {
                    Toast.makeText(LoginActivity.this, "Please enter full details", Toast.LENGTH_SHORT).show();
                    return;
                }

                userLogin();

                break;
            case R.id.btnSignUp:
                Intent intent = new Intent(LoginActivity.this, RegistrationActivity.class);
               // intent.putExtra("keyName",mTxtlanguage.getText().toString());
                startActivity(intent);

                break;
            case R.id.btnadmin:

                Intent intent1 = new Intent(LoginActivity.this, AdminActivity.class);
                //intent1.putExtra("keyName",mTxtlanguage.getText().toString());
                startActivity(intent1);


                break;
            case R.id.txtDriverReg:
                startActivity(new Intent(LoginActivity.this,DriverLoginActivity.class));

                break;
            case R.id.btnChooseLang:
               chooselang();

                break;
                default:

        }
    }

    private void chooselang() {
        final String[] listitems={"English","हिंदी","मराठी"};
        AlertDialog.Builder mBuiler=new AlertDialog.Builder(LoginActivity.this);
        mBuiler.setTitle("Choose Language");
        mBuiler.setSingleChoiceItems(listitems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                if (i==0){
                    setLocale("en");
                    recreate();
                }else if (i==1){
                    setLocale("hi");
                    recreate();
                }else if (i==2){
                    setLocale("mr");
                    recreate();
                }

                dialog.dismiss();
            }
        });
        AlertDialog mDIalog=mBuiler.create();
        mDIalog.show();
    }

    private void setLocale(String lang) {
        Locale locale=new Locale(lang);
        Locale.setDefault(locale);
        Configuration config=new Configuration();
        config.locale=locale;
        getBaseContext().getResources().updateConfiguration(config,getBaseContext().getResources().getDisplayMetrics());
        SharedPreferences.Editor editor=getSharedPreferences("Settings",MODE_PRIVATE).edit();
        editor.putString("My_Lang",lang);
        editor.apply();
    }

    public void loadloccale(){
        SharedPreferences pref=getSharedPreferences("Settings",Activity.MODE_PRIVATE);
        String languag=pref.getString("My_Lang","");
        setLocale(languag);
    }
}
