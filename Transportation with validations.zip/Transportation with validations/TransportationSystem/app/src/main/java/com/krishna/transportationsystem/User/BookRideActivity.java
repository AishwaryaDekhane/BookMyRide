package com.krishna.transportationsystem.User;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.krishna.transportationsystem.IPConfig;

import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class BookRideActivity extends AppCompatActivity {

    private Button mBtnFindPath,mBtnConfirmedRide;
    private EditText editTextOrigin;
    private EditText editTextDestination;
    private TextView txtCost;
    private BottomNavigationView mMainNav,mMainCar,mMainBus,mMainBike,mMainTruck;
    RelativeLayout mRelativeCarType,mRelativeBusType,
            mRelativeBikeType,mRelativeTruckType;
    String pick_up;
    String destinaton;
    String ride;
    String payment;
    TextView txtPick,txtDest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_ride);

        mBtnFindPath = findViewById(R.id.btnRequest);
        mBtnConfirmedRide=findViewById(R.id.btnShowConfirmedRide);
        editTextOrigin = findViewById(R.id.editTextOrigin);
        editTextDestination =findViewById(R.id.editTextDestination);
        txtCost=findViewById(R.id.txtCost);
        txtPick=findViewById(R.id.txtPickUp1);
        txtDest=findViewById(R.id.txtDest);
        mMainNav= findViewById(R.id.main_nav);
        mMainCar=findViewById(R.id.main_nav_car);
        mMainBike=findViewById(R.id.main_nav_bike);
        mMainBus=findViewById(R.id.main_nav_bus);
        mMainTruck=findViewById(R.id.main_nav_truck);
        mRelativeCarType=findViewById(R.id.relLayoutCarType);
        mRelativeBusType=findViewById(R.id.relLayoutBusType);
        mRelativeBikeType=findViewById(R.id.relLayoutBikeType);
        mRelativeTruckType=findViewById(R.id.relLayoutTruckType);


        mMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_car:
                        mRelativeCarType.setVisibility(View.VISIBLE);
                        mRelativeBusType.setVisibility(View.GONE);
                        mRelativeBikeType.setVisibility(View.GONE);
                        mRelativeTruckType.setVisibility(View.GONE);


                        return true;
                    case R.id.menu_bus:
                        mRelativeCarType.setVisibility(View.GONE);
                        mRelativeBusType.setVisibility(View.VISIBLE);
                        mRelativeBikeType.setVisibility(View.GONE);
                        mRelativeTruckType.setVisibility(View.GONE);



                        return true;
                    case R.id.menu_bike:
                        mRelativeCarType.setVisibility(View.GONE);
                        mRelativeBusType.setVisibility(View.GONE);
                        mRelativeBikeType.setVisibility(View.VISIBLE);
                        mRelativeTruckType.setVisibility(View.GONE);

                        return true;
                    case R.id.menu_truck:
                        mRelativeCarType.setVisibility(View.GONE);
                        mRelativeBusType.setVisibility(View.GONE);
                        mRelativeBikeType.setVisibility(View.GONE);
                        mRelativeTruckType.setVisibility(View.VISIBLE);

                        return true;

                    default:
                        return false;

                }
            }
        });

        mMainCar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_car_4_sit:

                        Snackbar.make(findViewById(R.id.mainContainer), "by 4 seater Car Costing "+"2400", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("2400");
                        ride="car 4 seater";

                        return true;
                    case R.id.menu_car_6_sit:

                        Snackbar.make(findViewById(R.id.mainContainer), "by 6 seater Car Costing "+"2800", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("2800");
                        ride="car 6 seater";

                        return true;
                    case R.id.menu_car_12_sit:

                        Snackbar.make(findViewById(R.id.mainContainer), "by 12 seater Car Costing "+"3200", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("3200");
                        ride="car 12 seater";

                        return true;

                    default:
                        return false;

                }
            }
        });
        mMainBike.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_bike:

                        Snackbar.make(findViewById(R.id.mainContainer), "by Bike Costing "+"400", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("400");
                        ride="bike";

                        return true;
                    case R.id.menu_auto:

                        Snackbar.make(findViewById(R.id.mainContainer), "by Auto Costing "+"800", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("800");
                        ride="auto";

                        return true;
                    case R.id.menu_mini_truck:

                        Snackbar.make(findViewById(R.id.mainContainer), "by Mini Truck Costing "+"1200", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("1200");
                        ride="mini truck";

                        return true;

                    default:
                        return false;

                }
            }
        });

        mMainBus.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_bus_20_seat:

                        Snackbar.make(findViewById(R.id.mainContainer), "by 20 seater Bus Costing "+"2500", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("2500");
                        ride="bus 20 seater";

                        return true;
                    case R.id.menu_mini_bus:

                        Snackbar.make(findViewById(R.id.mainContainer), "by mini Bus Costing "+"5000", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("2500");
                        ride="mini bus";

                        return true;
                    case R.id.menu_bus_50_seat:

                        Snackbar.make(findViewById(R.id.mainContainer), "by 50 seater Bus Costing "+"7500", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("7500");
                        ride="bus 50 seater";

                        return true;

                    default:
                        return false;

                }
            }
        });

        mMainTruck.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.menu_small_truck:

                        Snackbar.make(findViewById(R.id.mainContainer), "by Small Transportaion Costing "+"2500", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("2500");
                        ride="small transportaion";

                        return true;
                    case R.id.menu_medium_truck:

                        Snackbar.make(findViewById(R.id.mainContainer), "by Medium Transportaion Costing "+"5000", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("5000");
                        ride="medium transportaion";

                        return true;
                    case R.id.menu_large_truck:

                        Snackbar.make(findViewById(R.id.mainContainer), "by Large Transportaion  Costing "+"7500", Snackbar.LENGTH_LONG)
                                .setAction("Action", null).show();
                        txtCost.setText("7500");
                        ride="large transportaion";

                        return true;

                    default:
                        return false;

                }
            }
        });

        mBtnFindPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editTextOrigin.getText().toString().equals("") ||
                        editTextOrigin.getText().toString().equals("")  ) {
                    Toast.makeText(BookRideActivity.this, "Please enter full details", Toast.LENGTH_SHORT).show();
                return;
                }
                sendRequest(ride,payment);

            }
        });

        getConfirmed();

        mBtnConfirmedRide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MapsActivity.class);

                intent.putExtra("pick_up", txtPick.getText().toString());
                intent.putExtra("destination", txtDest.getText().toString());
                startActivity(intent);
                finish();
                deleteRide();
                generateotp();

            }
        });


    }

    public void getConfirmed(){
        final String user_email= SharedPrefManager.getInstance(BookRideActivity.this).getUserEmail();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, IPConfig.GET_CONFIRMED_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {

                                 pick_up= obj.getString("pick_up");
                                 destinaton=obj.getString("dest_point");
                                 txtPick.setText(pick_up);
                                 txtDest.setText(destinaton);

                                Toast.makeText(
                                        getApplicationContext(),
                                        "Pick up: "+pick_up+"\n"+"Destination point: "+destinaton,
                                        Toast.LENGTH_LONG
                                ).show();
                                mBtnConfirmedRide.setVisibility(View.VISIBLE);
                                if (pick_up.equals("null")){
                                    mBtnConfirmedRide.setVisibility(View.GONE);
                                }
                            } else {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                                mBtnConfirmedRide.setVisibility(View.GONE);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(
                        getApplicationContext(),
                        error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("user_email",user_email);
                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(BookRideActivity.this);
        requestQueue.add(stringRequest);
    }

    public void deleteRide(){
        final String user_email= SharedPrefManager.getInstance(BookRideActivity.this).getUserEmail();

        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                IPConfig.DELETE_RIDE_URL+user_email,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(BookRideActivity.this, response, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(BookRideActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {

                return new HashMap<>();
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(BookRideActivity.this);
        requestQueue.add(stringRequest);

    }

    public void generateotp(){

        final String user_email= SharedPrefManager.getInstance(BookRideActivity.this).getUserEmail();
        RequestQueue queue = Volley.newRequestQueue(BookRideActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, IPConfig.GENERATE_OTP_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                if (response.contains("Success")){

                    Toast.makeText(BookRideActivity.this,"request sent",Toast.LENGTH_SHORT).show();
                }
                Log.i("My success",""+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(BookRideActivity.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {

                Map<String,String> map = new HashMap<>();

                map.put("user_email",user_email);
                map.put("note","OTP successfully matched");

                return map;
            }
        };
        queue.add(request);
    }

    public void sendRequest(final String vehicle,final String payment) {

        final String pick_up=editTextOrigin.getText().toString();
        final String dest_point=editTextDestination.getText().toString();
        final String cost=txtCost.getText().toString();

        final String user_email= SharedPrefManager.getInstance(BookRideActivity.this).getUserEmail();
        RequestQueue queue = Volley.newRequestQueue(BookRideActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, IPConfig.BOOK_REQUEST_URL, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                if (response.contains("Success")){

                    Toast.makeText(BookRideActivity.this,"request sent",Toast.LENGTH_SHORT).show();
                }
                Log.i("My success",""+response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(BookRideActivity.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() {

                Map<String,String> map = new HashMap<>();

                map.put("user_email",user_email);
                map.put("pick_up",pick_up);
                map.put("dest_point",dest_point);
                map.put("vehicle_type",vehicle);
                map.put("payment",payment);
                map.put("cost",cost);


                return map;
            }
        };
        queue.add(request);
    }


    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch(view.getId()) {
            case R.id.radio_card:
                if (checked)
                    payment="card";
                final FragmentManager fm=getSupportFragmentManager();
                final ItemFragment itemFragment=new ItemFragment();

                //Pass area name and table no to next menuFragment
                Bundle bundle = new Bundle();

                itemFragment.setArguments(bundle);

                itemFragment.show(fm,"Item");
                Toast.makeText(BookRideActivity.this,"card",Toast.LENGTH_LONG).show();
                    break;
            case R.id.radio_cash:
                if (checked)
                    payment="cash";
                    Toast.makeText(BookRideActivity.this,"cash",Toast.LENGTH_LONG).show();

                    break;
        }

    }
}
