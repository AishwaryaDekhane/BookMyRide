package com.krishna.transportationsystem.Driver;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;

import java.util.ArrayList;

class UserRequestAdapter extends RecyclerView.Adapter<UserRequestAdapter.RequestViewHolder> {

    private Context mContext;
    private ArrayList<ModelClass> mListUser;

    public UserRequestAdapter(Context mContext, ArrayList<ModelClass> mListUser) {
        this.mContext = mContext;
        this.mListUser = mListUser;
    }

    @NonNull
    @Override
    public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.adapter_request_user, viewGroup, false);

        return new RequestViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {

        holder.mTxtUserRequestId.setText(mListUser.get(position).getRequestId());
        holder.mTxtUserName.setText(mListUser.get(position).getUserEmail());
        holder.mTxtUserPick.setText(mListUser.get(position).getPickup());
        holder.mTxtUserDestPt.setText(mListUser.get(position).getDestinationPoint());
        holder.mTxtUserVehicleType.setText(mListUser.get(position).getVehicleType());
        holder.mBtnConfirmed.setText(mListUser.get(position).getConfirmed());
        holder.mTxtPayment.setText(mListUser.get(position).getPayment());
        holder.mTxtCost.setText(mListUser.get(position).getCost());


        if (holder.mBtnConfirmed.getText().toString().equals("Confirmed")){
            holder.mBtnAccept.setVisibility(View.GONE);
            holder.mBtnConfirmed.setVisibility(View.VISIBLE);
        }else {
            holder.mBtnAccept.setVisibility(View.VISIBLE);
            holder.mBtnConfirmed.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mListUser.size();
    }

    public class RequestViewHolder extends RecyclerView.ViewHolder {
        private TextView mTxtUserRequestId,mTxtUserName,
                mTxtUserPick,mTxtUserDestPt,mTxtUserVehicleType,
                mTxtPayment,mTxtCost;
        private Button mBtnAccept,mBtnConfirmed;

        public RequestViewHolder(@NonNull View itemView) {
            super(itemView);

            mTxtUserRequestId=itemView.findViewById(R.id.txtRequestUserId);
            mTxtUserName=itemView.findViewById(R.id.txtRequestUserName);
            mTxtUserPick=itemView.findViewById(R.id.txtRequestUserPickUpPt);
            mTxtUserDestPt=itemView.findViewById(R.id.txtRequestUserDestPt);
            mTxtUserVehicleType=itemView.findViewById(R.id.txtRequestUserVehicleType);
            mBtnAccept=itemView.findViewById(R.id.btnUserRequestAccept);
            mBtnConfirmed=itemView.findViewById(R.id.btnRequestUserConfirmed);
            mTxtPayment=itemView.findViewById(R.id.txtPayment1);
            mTxtCost=itemView.findViewById(R.id.txtCost);

            mBtnAccept.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ModelClass modelClass=mListUser.get(getAdapterPosition());
                    mClickListener.onAcceptClick(modelClass);
                }
            });


        }
    }

    public interface AcceptClickListener {
        void onAcceptClick(ModelClass modelClass);
    }
    private AcceptClickListener mClickListener;

    public void setAcceptClickListener(AcceptClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

}