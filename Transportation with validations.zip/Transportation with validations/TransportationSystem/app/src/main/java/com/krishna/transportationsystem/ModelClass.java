package com.krishna.transportationsystem;

public class ModelClass {
    String DriverId,DriverName,DriverEmail,DriverMobile,
            DriverArea,DriverLicence,DriverAadhar,Accepted;
    String Pickup,UserEmail,DestinationPoint,VehicleType,RequestId,
            Confirmed,Payment,Cost,pick,help;


    public String getDriverName() {
        return DriverName;
    }

    public void setDriverName(String driverName) {
        DriverName = driverName;
    }

    public String getPick() {
        return pick;
    }

    public void setPick(String pick) {
        this.pick = pick;
    }

    public String getHelp() {
        return help;
    }

    public void setHelp(String help) {
        this.help = help;
    }

    public String getDriverEmail() {
        return DriverEmail;
    }

    public void setDriverEmail(String driverEmail) {
        DriverEmail = driverEmail;
    }

    public String getConfirmed() {
        return Confirmed;
    }

    public void setConfirmed(String confirmed) {
        Confirmed = confirmed;
    }

    public String getDriverId() {
        return DriverId;
    }

    public void setDriverId(String driverId) {
        DriverId = driverId;
    }

    public String getAccepted() {
        return Accepted;
    }

    public void setAccepted(String accepted) {
        Accepted = accepted;
    }


    public String getDriverMobile() {
        return DriverMobile;
    }

    public void setDriverMobile(String driverMobile) {
        DriverMobile = driverMobile;
    }

    public String getDriverArea() {
        return DriverArea;
    }

    public void setDriverArea(String driverArea) {
        DriverArea = driverArea;
    }

    public String getPickup() {
        return Pickup;
    }

    public void setPickup(String pickup) {
        Pickup = pickup;
    }

    public String getRequestId() {
        return RequestId;
    }

    public void setRequestId(String requestId) {
        RequestId = requestId;
    }

    public String getDestinationPoint() {
        return DestinationPoint;
    }

    public void setDestinationPoint(String destinationPoint) {
        DestinationPoint = destinationPoint;
    }

    public String getUserEmail() {
        return UserEmail;
    }

    public void setUserEmail(String userEmail) {
        UserEmail = userEmail;
    }

    public String getVehicleType() {
        return VehicleType;
    }

    public void setVehicleType(String vehicleType) {
        VehicleType = vehicleType;
    }

    public String getDriverLicence() {
        return DriverLicence;
    }

    public void setDriverLicence(String driverLicence) {
        DriverLicence = driverLicence;
    }

    public String getDriverAadhar() {
        return DriverAadhar;
    }

    public String getPayment() {
        return Payment;
    }

    public void setPayment(String payment) {
        Payment = payment;
    }

    public String getCost() {
        return Cost;
    }

    public void setCost(String cost) {
        Cost = cost;
    }

    public void setDriverAadhar(String driverAadhar) {
        DriverAadhar = driverAadhar;
    }
}
