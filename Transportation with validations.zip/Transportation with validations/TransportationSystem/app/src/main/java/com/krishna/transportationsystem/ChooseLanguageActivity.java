package com.krishna.transportationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.krishna.transportationsystem.User.LoginActivity;
import com.krishna.transportationsystem.User.NavActivity;

public class ChooseLanguageActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private RadioButton mRBEnglish,mRBHindi,mRBMarathi;
    private Button mBtnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_language);

        radioGroup = findViewById(R.id.radioGroup);
        radioGroup.clearCheck();
        mRBEnglish = findViewById(R.id.rb_english);
        mRBHindi = findViewById(R.id.rb_hindi);
        mRBMarathi = findViewById(R.id.rb_marathi);
        mBtnNext=findViewById(R.id.btnNext);
        if (SharedPrefManager.getInstance(this).isLoggedIn()){

            finish();
            startActivity(new Intent(this, NavActivity.class));
            return;
        }
        mBtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRBEnglish.isChecked()) {
                    Intent intent = new Intent(ChooseLanguageActivity.this, LoginActivity.class);
                    intent.putExtra("keyName","english");
                    startActivity(intent);
                } else if (mRBHindi.isChecked()) {
                    Intent intent = new Intent(ChooseLanguageActivity.this, LoginActivity.class);
                    intent.putExtra("keyName","hindi");
                    startActivity(intent);
                    /*Intent intent=new Intent(new Intent(ChooseLanguageActivity.this,LoginActivity.class));
                    intent.putExtra("language","Marathi");
                    finish();*/
                } else if (mRBMarathi.isChecked()) {
                    Intent intent = new Intent(ChooseLanguageActivity.this, LoginActivity.class);
                    intent.putExtra("keyName","marathi");
                    startActivity(intent);
                    /*Intent intent=new Intent(new Intent(ChooseLanguageActivity.this,LoginActivity.class));
                    intent.putExtra("language","Hindi");
                    finish();*/
                }
            }
        });


    }
}
