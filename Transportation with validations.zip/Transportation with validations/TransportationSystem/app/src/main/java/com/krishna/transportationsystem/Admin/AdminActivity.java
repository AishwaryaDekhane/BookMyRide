package com.krishna.transportationsystem.Admin;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.krishna.transportationsystem.R;

import java.util.Locale;


public class AdminActivity extends AppCompatActivity {

    private EditText mEdtUsername,mEdtPassword;
    private Button mBtnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        init();

    }

    private void init() {
        mEdtUsername=findViewById(R.id.edtAdminUsername);
        mEdtPassword=findViewById(R.id.edtAdminPassword);

        mBtnLogin=findViewById(R.id.btnAdminLogin);
        mBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user=mEdtUsername.getText().toString().trim();
                String pass=mEdtPassword.getText().toString().trim();
                if(user.equals("admin")&& pass.equals("admin"))
                {
                    Toast.makeText(AdminActivity.this,"login successful!",Toast.LENGTH_LONG).show();
                    startActivity(new Intent(AdminActivity.this,MainActivity.class));
                    finish();
                }else {
                    Toast.makeText(AdminActivity.this,"incorrect username or password ",Toast.LENGTH_LONG).show();
                }
            }
        });
    }


}
