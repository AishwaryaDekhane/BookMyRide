package com.krishna.transportationsystem.Driver;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;
import com.krishna.transportationsystem.User.LoginActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class OTPMatchedFragment extends DialogFragment {

    private EditText mEdtOTPNo;
    private TextView mTxtNote;
    private Button mBtnDoneDialog;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.otp_match_fragment,container);

        mEdtOTPNo=view.findViewById(R.id.edtOTPNo);
        mTxtNote=view.findViewById(R.id.txtGetMsg);
        mBtnDoneDialog=view.findViewById(R.id.btnMatchedOTP);


        mBtnDoneDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendOTP();
            }
        });


        return view;
    }

    private void sendOTP() {
        final String otp=mEdtOTPNo.getText().toString().trim();
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, IPConfig.DRIVER_MATCH_OTP_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {

                                                obj.getString("id");

                                String otp=obj.getString("note");
                                mTxtNote.setText(otp);

                            } else {
                                Toast.makeText(
                                        getContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(
                        getContext(),
                        error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("rand_no", otp);

                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);



    }





}
