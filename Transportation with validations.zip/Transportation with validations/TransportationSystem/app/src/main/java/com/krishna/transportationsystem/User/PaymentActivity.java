package com.krishna.transportationsystem.User;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import com.krishna.transportationsystem.R;

public class PaymentActivity extends AppCompatActivity {

    String payment;
    Button mBtnSubmit;
    public static final String MY_PREFS_NAME = "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        mBtnSubmit=findViewById(R.id.bAddPayment);
        mBtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getBaseContext(), NavActivity.class);
                intent.putExtra("cash", payment);
                startActivity(intent);
                finish();
                /*SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();
                editor.putString("payment_mode", payment);
                editor.apply();*/
                Toast.makeText(PaymentActivity.this,payment,Toast.LENGTH_LONG).show();
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        switch(view.getId()) {
            case R.id.radio_card:
                if (checked)
                    payment="card";
                final FragmentManager fm=getSupportFragmentManager();
                final ItemFragment itemFragment=new ItemFragment();

                //Pass area name and table no to next menuFragment
                Bundle bundle = new Bundle();

                itemFragment.setArguments(bundle);

                itemFragment.show(fm,"Item");
                Toast.makeText(PaymentActivity.this,"card",Toast.LENGTH_LONG).show();
                break;
            case R.id.radio_cash:
                if (checked)
                    payment="cash";
                Toast.makeText(PaymentActivity.this,"cash",Toast.LENGTH_LONG).show();

                break;
        }

    }

}
