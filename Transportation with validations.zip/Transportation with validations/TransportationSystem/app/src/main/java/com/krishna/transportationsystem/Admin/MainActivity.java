package com.krishna.transportationsystem.Admin;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private ArrayList<ModelClass> mListNotifications;
    RecyclerView recyclerView;
    private RequestQueue requestQueue;
    ViewDriverAdapter adapter;
    ProgressDialog progressDialog;
    String driverId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerDriverList);
        mListNotifications = new ArrayList<>();

        requestQueue = Volley.newRequestQueue(MainActivity.this);
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                IPConfig.GET_DRIVER_LIST_URL, null, new SuccessListener(),
                new FailureListener());

        requestQueue.add(jsonObjectRequest);
        progressDialog =new ProgressDialog(MainActivity.this);
    }

    class SuccessListener implements Response.Listener<JSONObject>{

        @Override
        public void onResponse(JSONObject response) {

            Log.e("Response", "data:" + response.toString());

            try {

                JSONArray jsonOrders = (JSONArray) response.get("result");
                for (int i = 0; i < jsonOrders.length(); i++)

                {
                    ModelClass modelClass = new ModelClass();
                    JSONObject jsonObject1 = jsonOrders.getJSONObject(i);
                    driverId=jsonObject1.getString("flag");
                    modelClass.setDriverId(jsonObject1.getString("id"));
                    modelClass.setDriverName(jsonObject1.getString("name"));
                    modelClass.setDriverEmail(jsonObject1.getString("email"));
                    modelClass.setDriverMobile(jsonObject1.getString("mobile"));
                    modelClass.setDriverLicence(jsonObject1.getString("driving_lic"));
                    modelClass.setDriverAadhar(jsonObject1.getString("aadhar"));
                    if (driverId.equals("1")) {
                        modelClass.setAccepted("Accepted");
                    }
                    mListNotifications.add(modelClass);

                }

                adapter = new ViewDriverAdapter(MainActivity.this, mListNotifications);
                adapter.setAcceptClickListener(new MyAcceptBtnListener());
                recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            adapter.notifyDataSetChanged();

        }

    }
    class FailureListener implements Response.ErrorListener {

        @Override
        public void onErrorResponse(VolleyError error) {
            Log.e("error",error.toString());
        }
    }

    class MyAcceptBtnListener implements ViewDriverAdapter.AcceptClickListener{

        @Override
        public void onAcceptClick(ModelClass modelClass) {
            StringRequest stringRequest = new StringRequest(Request.Method.POST,
                    IPConfig.SEND_DRIVER_ACCEPT_URL+modelClass.getDriverId(),
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Toast.makeText(MainActivity.this, response, Toast.LENGTH_LONG).show();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();

                    params.put("flag", "1");


                    return params;
                }
            };
            RequestQueue requestQueue=Volley.newRequestQueue(MainActivity.this);
            requestQueue.add(stringRequest);

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.help_request) {

            startActivity(new Intent(MainActivity.this,HelpRequestActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
