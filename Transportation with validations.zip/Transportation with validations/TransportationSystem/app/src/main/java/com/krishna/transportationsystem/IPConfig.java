package com.krishna.transportationsystem;

public class IPConfig {

    //Main URL
    private static String MAIN_URL = "http://172.16.24.179/transportation_db/v1/";

    // Login URL
    public static String LOGIN_URL = MAIN_URL +"user_login.php";
    public static String REGISTER_URL = MAIN_URL +"user_reg.php";
    public static String BOOK_REQUEST_URL = MAIN_URL +"book_request.php";
    public static String SEND_BOOK_REQUEST_URL = MAIN_URL +"send_book_request.php";

    public static String DRIVER_REGISTER_URL = MAIN_URL +"driver_reg.php";
    public static final String GET_DRIVER_LIST_URL=MAIN_URL +"get_driver.php";
    public static final String SEND_DRIVER_ACCEPT_URL=MAIN_URL +"send_driver_aacept.php?id=";
    public static String DRIVER_LOGIN_URL = MAIN_URL +"driver_login.php";
    public static final String GET_USER_REQUEST_URL=MAIN_URL +"get_user_request.php";
    public static final String USER_REQUEST_ACCEPT_URL=MAIN_URL +"user_ride_accept.php?id=";
    public static String GET_CONFIRMED_URL = MAIN_URL +"get_confirmed.php";
    public static final String DELETE_RIDE_URL=MAIN_URL +"delete_ride.php?user_email=";
    public static final String GENERATE_OTP_URL=MAIN_URL +"generate_otp.php";
    public static String GET_OTP_URL = MAIN_URL +"get_otp.php?user_email=";
    public static String DRIVER_MATCH_OTP_URL = MAIN_URL +"driver_match_otp.php";
    public static final String GET_USER_HISTORY_URL=MAIN_URL +"get_user_history.php";
    public static String GET_HELP_URL = MAIN_URL +"get_help.php";
    public static String SEND_HELP_URL = MAIN_URL +"send_help.php";



}
