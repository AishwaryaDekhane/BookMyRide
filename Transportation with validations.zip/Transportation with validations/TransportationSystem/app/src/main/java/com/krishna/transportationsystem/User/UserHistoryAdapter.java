package com.krishna.transportationsystem.User;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;

import java.util.ArrayList;

class UserHistoryAdapter extends RecyclerView.Adapter<UserHistoryAdapter.HistViewHolder> {

    private Context mContext;
    private ArrayList<ModelClass> mListUser;

    public UserHistoryAdapter(Context mContext, ArrayList<ModelClass> mListUser) {
        this.mContext = mContext;
        this.mListUser = mListUser;
    }

    @NonNull
    @Override
    public HistViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.adapter_user_history, viewGroup, false);

        return new HistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistViewHolder holder, int position) {

        holder.mTxtPick.setText(mListUser.get(position).getPick());
        holder.mTxtUserDestPt.setText(mListUser.get(position).getDestinationPoint());
        holder.mTxtUserVehicleType.setText(mListUser.get(position).getVehicleType());
        holder.mTxtCost.setText(mListUser.get(position).getCost());


    }

    @Override
    public int getItemCount() {
        return mListUser.size();
    }

    public class HistViewHolder extends RecyclerView.ViewHolder {
        private TextView
                mTxtPick,mTxtUserDestPt,mTxtUserVehicleType,
                mTxtCost;

        public HistViewHolder(@NonNull View itemView) {
            super(itemView);

            mTxtPick=itemView.findViewById(R.id.txtHistPick);
            mTxtUserDestPt=itemView.findViewById(R.id.txtHistDest);
            mTxtUserVehicleType=itemView.findViewById(R.id.txtHistVehicleType);
            mTxtCost=itemView.findViewById(R.id.txtHistCost);

        }
    }

}