package com.krishna.transportationsystem.Admin;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.krishna.transportationsystem.ModelClass;
import com.krishna.transportationsystem.R;

import java.util.ArrayList;

class HelpRequestAdapter extends RecyclerView.Adapter<HelpRequestAdapter.DriverViewHolder> {

    private Context mContext;
    private ArrayList<ModelClass> mListDriver;

    public HelpRequestAdapter(Context mContext, ArrayList<ModelClass> mListDriver) {
        this.mContext = mContext;
        this.mListDriver = mListDriver;
    }

    @NonNull
    @Override
    public DriverViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.adapter_help_request, viewGroup, false);

        return new DriverViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DriverViewHolder holder, int position) {

        holder.mTxtHelpRequest.setText(mListDriver.get(position).getHelp());


    }

    @Override
    public int getItemCount() {
        return mListDriver.size();
    }

    public class DriverViewHolder extends RecyclerView.ViewHolder {
        private TextView mTxtHelpRequest;

        public DriverViewHolder(@NonNull View itemView) {
            super(itemView);

            mTxtHelpRequest=itemView.findViewById(R.id.txtHelprequest);


        }
    }


}