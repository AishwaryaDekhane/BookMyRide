package com.krishna.transportationsystem.Driver;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.krishna.transportationsystem.IPConfig;
import com.krishna.transportationsystem.R;
import com.krishna.transportationsystem.SharedPrefManager;
import com.krishna.transportationsystem.User.RegistrationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class DriverLoginActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText mEdtUsername,mEdtPassword;
    private Button mBtnSignIn,mBtnSignUp;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_login);
        init();
        if (SharedPrefManager.getInstance(this).isDriverLoggedIn()){

            finish();
            startActivity(new Intent(this, DriverActivity.class));
        }

    }

    private void init() {
        mEdtUsername=findViewById(R.id.edtDriverEmail);
        mEdtPassword=findViewById(R.id.edtDriverPassword);
        mBtnSignIn=findViewById(R.id.btnDriverSignIn);
        mBtnSignUp=findViewById(R.id.btnDriverSignUp);
        mBtnSignUp.setOnClickListener(this);
        mBtnSignIn.setOnClickListener(this);

        progressDialog=new ProgressDialog(DriverLoginActivity.this);

    }

    private void driverLogin() {

        final String email = mEdtUsername.getText().toString().trim();
        final String password = mEdtPassword.getText().toString().trim();

        progressDialog.show();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST, IPConfig.DRIVER_LOGIN_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {
                                SharedPrefManager.getInstance(getApplicationContext()).
                                        driverLogin(
                                                obj.getInt("id"),
                                                obj.getString("name"),
                                                obj.getString("email")
                                        );
                                startActivity(new Intent(getApplicationContext(), DriverActivity.class));
                                finish();
                            } else {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
                Toast.makeText(
                        getApplicationContext(),
                        error.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);

                return params;
            }
        };
        RequestQueue requestQueue=Volley.newRequestQueue(DriverLoginActivity.this);
        requestQueue.add(stringRequest);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnDriverSignIn:
                if (mEdtUsername.toString().equals("") ||
                        mEdtPassword.toString().equals("")) {
                    Toast.makeText(DriverLoginActivity.this, "Please enter full details", Toast.LENGTH_SHORT).show();
                    return;
                }

                driverLogin();

                break;
            case R.id.btnDriverSignUp:
                startActivity(new Intent(DriverLoginActivity.this,DriverRegActivity.class));
                break;

            default:

        }
    }
}
