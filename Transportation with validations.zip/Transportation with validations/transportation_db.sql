-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2019 at 10:33 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transportation_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_request`
--

CREATE TABLE `book_request` (
  `id` int(11) NOT NULL,
  `user_email` varchar(20) NOT NULL,
  `pick_up` varchar(20) NOT NULL,
  `dest_point` varchar(20) NOT NULL,
  `vehicle_type` varchar(20) NOT NULL,
  `payment` varchar(200) NOT NULL,
  `cost` varchar(290) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `driver_reg`
--

CREATE TABLE `driver_reg` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `area` text NOT NULL,
  `driving_lic` varchar(20) NOT NULL,
  `aadhar` varchar(20) NOT NULL,
  `flag` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver_reg`
--

INSERT INTO `driver_reg` (`id`, `name`, `email`, `password`, `mobile`, `area`, `driving_lic`, `aadhar`, `flag`) VALUES
(1, 'harshal sharma', 'h', 'h', '84', 'h', 'h', 'h', 0),
(6, 'h1', 'h1', 'h1', '86', 'h1', 'h1', 'h1', 0),
(7, 'rajesh', 'r', 'r', '8', 'r', 'r', 'r', 0),
(8, 'g', 'g', 'g', '8', 'g', 'g', 'g', 1),
(9, 'y', 'y', 'y', '3', 'y', 'y', 'y', 1);

-- --------------------------------------------------------

--
-- Table structure for table `generate_otp`
--

CREATE TABLE `generate_otp` (
  `id` int(11) NOT NULL,
  `user_email` varchar(20) NOT NULL,
  `rand_no` int(11) NOT NULL,
  `note` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `generate_otp`
--

INSERT INTO `generate_otp` (`id`, `user_email`, `rand_no`, `note`) VALUES
(9, 'h', 2759, 'OTP successfully matched'),
(10, 'h', 2537, 'OTP successfully matched'),
(11, 'h', 1443, 'OTP successfully matched'),
(12, 'h', 7169, 'OTP successfully matched'),
(13, 'h', 4087, 'OTP successfully matched'),
(14, 'h', 7800, 'OTP successfully matched'),
(15, 'h', 7898, 'OTP successfully matched'),
(16, 'h', 2199, 'OTP successfully matched'),
(17, 'h', 3353, 'OTP successfully matched'),
(18, 'h', 5892, 'OTP successfully matched'),
(19, 'h', 9134, 'OTP successfully matched'),
(20, 'h', 3826, 'OTP successfully matched');

-- --------------------------------------------------------

--
-- Table structure for table `help`
--

CREATE TABLE `help` (
  `id` int(11) NOT NULL,
  `user_name` varchar(240) NOT NULL,
  `topic` text NOT NULL,
  `help` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `help`
--

INSERT INTO `help` (`id`, `user_name`, `topic`, `help`) VALUES
(1, 'h', 'Trip Issues and Refunds', ' I am not able to get trip'),
(2, 'h', 'Trip Issues and Refunds', ' I am not able to get trip'),
(3, 'h', 'Account and Payment', 'gh'),
(4, 'h', 'A Guid to App', 'gh'),
(5, 'h', 'More', 'gh'),
(6, 'h', 'Trip Issues and Refunds', 'dgb'),
(7, 'h', 'Trip Issues and Refunds', 'ft dj'),
(8, 'h', 'Trip Issues and Refunds', 'dhhv'),
(9, 'h', 'Trip Issues and Refunds', 'dhhv'),
(10, 'h', 'Trip Issues and Refunds', 'Trip isssue');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_mode`
--

CREATE TABLE `payment_mode` (
  `id` int(11) NOT NULL,
  `user_email` varchar(240) NOT NULL,
  `payment_mode` varchar(240) DEFAULT 'cash'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_mode`
--

INSERT INTO `payment_mode` (`id`, `user_email`, `payment_mode`) VALUES
(1, 'h', 'cash');

-- --------------------------------------------------------

--
-- Table structure for table `user_history`
--

CREATE TABLE `user_history` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(240) NOT NULL,
  `pick` varchar(240) NOT NULL,
  `dest` varchar(240) NOT NULL,
  `cost` varchar(240) NOT NULL,
  `vehicle_typ` varchar(240) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_history`
--

INSERT INTO `user_history` (`user_id`, `user_name`, `pick`, `dest`, `cost`, `vehicle_typ`) VALUES
(1, 'h', 'Pune', 'Mumbai', '2800', 'car 6 seater'),
(2, 'h', 'Swargate ', 'Tilak Road', '1280', 'large transportaion'),
(3, 'h', 'Shivajinagar', 'JM Road', '99', 'car 4 seater'),
(4, 'h', 'Pune', 'Mumbai', '427', 'mini bus'),
(5, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(6, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(7, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(8, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(9, 'h', 'Mahabaleshwar', 'Pune', '200', 'car 4 seater'),
(10, 'h', 'Kashmir', 'Kanyakumari', '300', 'car 6 seater'),
(11, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(12, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(13, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(14, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(15, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(16, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(17, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(18, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(19, 'h', 'Pune', 'Mumbai', '300', 'car 6 seater'),
(20, 'h', 'Pune', 'Mumbai', '200', 'car 4 seater'),
(21, 'h', 'Pune', 'Mumbai', '300', 'car 6 seater'),
(22, 'h', 'Pune', 'Mumbai', '300', 'car 6 seater'),
(23, 'h', 'Pune', 'Mumbai', '300', 'car 6 seater'),
(24, 'h', 'Pune', 'Mumbai', '300', 'car 6 seater');

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `user_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `area` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`user_id`, `name`, `email`, `password`, `mobile`, `area`) VALUES
(2, 'h', 'h', 'h', 8, 'h');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_request`
--
ALTER TABLE `book_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `driver_reg`
--
ALTER TABLE `driver_reg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generate_otp`
--
ALTER TABLE `generate_otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `help`
--
ALTER TABLE `help`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_mode`
--
ALTER TABLE `payment_mode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_history`
--
ALTER TABLE `user_history`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_request`
--
ALTER TABLE `book_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `driver_reg`
--
ALTER TABLE `driver_reg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `generate_otp`
--
ALTER TABLE `generate_otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `help`
--
ALTER TABLE `help`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_mode`
--
ALTER TABLE `payment_mode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_history`
--
ALTER TABLE `user_history`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `user_reg`
--
ALTER TABLE `user_reg`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
