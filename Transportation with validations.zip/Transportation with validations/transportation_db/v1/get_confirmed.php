
<?php 
 
require_once '../include/DbOperations.php';
 
$response = array(); 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(isset($_POST['user_email'])){
        $db = new DbOperations(); 
 
        if($db->getConfirmed($_POST['user_email'])){
            $user = $db->getConfirmedByUser($_POST['user_email']);
            $response['error'] = false; 
            $response['user_email'] = $user['user_email'];
             $response['pick_up'] = $user['pick_up'];
            $response['dest_point'] = $user['dest_point'];
             $response['vehicle_type'] = $user['vehicle_type'];
            
        }else{
            $response['error'] = true; 
            $response['message'] = "Not Confirmed Ride";          
        }
 
    }else{
        $response['error'] = true; 
        $response['message'] = "Required fields are missing";
    }
}
 
echo json_encode($response);
?>