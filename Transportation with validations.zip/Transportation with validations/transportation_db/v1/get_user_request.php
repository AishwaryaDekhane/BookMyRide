<?php
 require_once('dbconfig.php');
 
 $sql = "SELECT `id`, `user_email`, `pick_up`, `dest_point`, `vehicle_type`, `payment`, `cost`, `flag` FROM `book_request`  ";
 
 $res = mysqli_query($con,$sql);
 
 $result = array();
 
 while($row = mysqli_fetch_array($res)){
 array_push($result,array('id'=>$row['id'],'user_email'=>$row['user_email'],'pick_up'=>$row['pick_up'], 'dest_point'=>$row['dest_point'], 
 	'vehicle_type'=>$row['vehicle_type'],'payment'=>$row['payment'],'cost'=>$row['cost'],'flag'=>$row['flag']));
 }
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);