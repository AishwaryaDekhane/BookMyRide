<?php
include 'dbconfig.php';

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

 $user_name = $_POST['user_name'];
 $topic=$_POST['topic'];
 
 $help=$_POST['help'];



 $Sql_Query = "INSERT INTO `help`(`user_name`, `topic`, `help`) VALUES ('$user_name','$topic','$help')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Sent';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>