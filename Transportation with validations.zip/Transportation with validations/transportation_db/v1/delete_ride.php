

<?php
require_once('dbconfig.php');


 $user_email=$_GET['user_email'];


 $sql = "DELETE FROM `book_request` WHERE `book_request`.`user_email` = '$user_email';  ";
 

 if(mysqli_query($con,$sql))
{
 echo 'Ride Confirmed';
}
else
{
 echo 'Something went wrong';
 }
 
 mysqli_close($con);
?>