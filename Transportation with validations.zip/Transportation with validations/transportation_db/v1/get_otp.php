<?php
 require_once('dbconfig.php');
 
 $user_email=$_GET['user_email'];

 $sql = "SELECT `id`, `user_email`, `rand_no` FROM `generate_otp` WHERE user_email ='$user_email' ";
 
 $res = mysqli_query($con,$sql);
 
 $result = array();
 
 while($row = mysqli_fetch_array($res)){
 array_push($result,array('id'=>$row['id'],'rand_no'=>$row['rand_no']));
 }
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);