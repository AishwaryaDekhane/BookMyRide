<?php
include 'dbconfig.php';

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

 $user_name = $_POST['user_name'];
 $pick = $_POST['pick'];
 $dest=$_POST['dest'];
 $cost=$_POST['cost'];
 $vehicle_typ=$_POST['vehicle_typ'];



 $Sql_Query = "INSERT INTO `user_history`(`user_name`, `pick`, `dest`, `cost`, `vehicle_typ`) VALUES ('$user_name','$pick','$dest','$cost','$vehicle_typ')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>