<?php
 require_once('dbconfig.php');
 
 $sql = "SELECT `user_id`, `user_name`, `pick`, `dest`, `cost`, `vehicle_typ` FROM `user_history` ";
 
 $res = mysqli_query($con,$sql);
 
 $result = array();
 
 while($row = mysqli_fetch_array($res)){
 array_push($result,array('user_id'=>$row['user_id'],'user_name'=>$row['user_name'],'pick'=>$row['pick'], 'dest'=>$row['dest'], 
 	'cost'=>$row['cost'],'vehicle_typ'=>$row['vehicle_typ']));
 }
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);