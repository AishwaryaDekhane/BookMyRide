
<?php 
 
require_once '../include/DbOperations.php';
 
$response = array(); 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(isset($_POST['rand_no'])){
        $db = new DbOperations(); 
 
        if($db->matchOTP($_POST['rand_no'])){
            $user = $db->getMatchOTPMsg($_POST['rand_no']);
            $response['error'] = false; 
            $response['id'] = $user['id'];
             $response['note'] = $user['note'];
            
        }else{
            $response['error'] = true; 
            $response['message'] = "Incorrect OTP";          
        }
 
    }else{
        $response['error'] = true; 
        $response['message'] = "Required fields are missing";
    }
}
 
echo json_encode($response);
?>