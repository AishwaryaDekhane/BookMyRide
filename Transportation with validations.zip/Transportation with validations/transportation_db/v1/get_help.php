<?php
 require_once('dbconfig.php');
 
 

 $sql = "SELECT `user_name`, `topic`, `help` FROM `help` ";
 
 $res = mysqli_query($con,$sql);
 
 $result = array();
 
 while($row = mysqli_fetch_array($res)){
 array_push($result,array('user_name'=>$row['user_name'],'topic'=>$row['topic'],'help'=>$row['help']));
 }
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);