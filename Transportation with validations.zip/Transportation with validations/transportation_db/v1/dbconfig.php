<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "transportation_db";  

$con = mysqli_connect($servername,$username,$password,$dbname) or die('Unable to Connect');
?>

