<?php
include 'dbconfig.php';

// Create connection
$con = new mysqli($servername, $username, $password, $dbname);

 $user_email = $_POST['user_email'];
 $pick_up = $_POST['pick_up'];
 $dest_point = $_POST['dest_point'];
 $vehicle_type=$_POST['vehicle_type'];
 $payment=$_POST['payment'];
 $cost=$_POST['cost'];



 $Sql_Query = "INSERT INTO `book_request`(`user_email`, `pick_up`, `dest_point`, `vehicle_type`,`payment`,`cost`) VALUES ('$user_email','$pick_up','$dest_point','$vehicle_type','$payment','$cost')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'request sent';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>