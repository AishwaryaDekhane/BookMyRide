<?php
	$objConnect = mysqli_connect("localhost","root","","pathhole_db");
	//$objDB = mysqli_select_db("");

	$strSQL = "SELECT * FROM `get_location`  ORDER BY LocationID  ASC ";

	$objQuery = mysqli_query($objConnect,$strSQL) or die(mysqli_error());
	$arrRows = array();
	$arryItem = array();
	while($arr = mysqli_fetch_array($objQuery)) {
		$arryItem["LocationID"] = $arr["LocationID"];
		$arryItem["Latitude"] = $arr["Latitude"];
		$arryItem["Longitude"] = $arr["Longitude"];
		
		$arrRows[] = $arryItem;
	}
		
echo json_encode($arrRows);
?>