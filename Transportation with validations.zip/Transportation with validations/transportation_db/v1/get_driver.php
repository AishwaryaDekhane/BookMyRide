<?php
 require_once('dbconfig.php');
 
 $sql = "SELECT  `id`,`name`, `email`, `mobile`, `driving_lic`, `aadhar`,`flag` FROM `driver_reg` ";
 
 $res = mysqli_query($con,$sql);
 
 $result = array();
 
 while($row = mysqli_fetch_array($res)){
 array_push($result,array('id'=>$row['id'],'name'=>$row['name'],'email'=>$row['email'], 'mobile'=>$row['mobile'], 'driving_lic'=>$row['driving_lic'],'aadhar'=>$row['aadhar'],'flag'=>$row['flag']));
 }
 
 echo json_encode(array("result"=>$result));
 
 mysqli_close($con);