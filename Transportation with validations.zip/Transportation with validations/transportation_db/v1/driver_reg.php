
<?php 
 
require_once '../include/DbOperations.php';
 
$response = array(); 
 
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(       
              isset($_POST['name']) and
              isset($_POST['email']) and
              isset($_POST['password']) and
              isset($_POST['mobile']) and
                isset($_POST['area']) and
               isset($_POST['driving_lic']) and
              isset($_POST['aadhar']))
        {
        //operate the data further 
 
      $db = new DbOperations();

      $result = $db->createDriver($_POST['name'], $_POST['email'],
                  $_POST['password'],$_POST['mobile'],$_POST['area'],$_POST['driving_lic'],$_POST['aadhar']
                  );

      if($result== 3){

         $response['error'] = false; 
        $response['message'] = "User registered successfully";

      }elseif($result==4){

         $response['error'] = true; 
    $response['message'] = "some error occured please try again";
      }
    
    }else{
        $response['error'] = true; 
        $response['message'] = "Required fields are missing";
    }
}else{
    $response['error'] = true; 
    $response['message'] = "Invalid Request";
}

echo json_encode($response);
