<?php
include 'dbconfig.php';

  $rand_no = rand(1111,9999);
  echo $rand_no;
$user_email = $_POST['user_email'];
$note = $_POST['note'];

 $Sql_Query = "INSERT INTO `generate_otp`(`user_email`, `rand_no`,`note`) VALUES ('$user_email', '$rand_no','$note')";
 
 if(mysqli_query($con,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>