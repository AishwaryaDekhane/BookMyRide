<?php
 
 if($_SERVER['REQUEST_METHOD']=='POST'){

 require_once('dbconfig.php'); 	
 
 $flag = $_POST['flag'];
 $id=$_GET['id'];
 
 
 $sql = "UPDATE `book_request` SET `flag`='$flag' WHERE id ='$id'";
 
 if(mysqli_query($con,$sql)){
 echo "Request Accepted";
 }
 
 mysqli_close($con);
 }else{
 echo "Error";
 }