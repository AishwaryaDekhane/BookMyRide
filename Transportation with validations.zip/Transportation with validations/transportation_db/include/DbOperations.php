<?php 
 
    class DbOperations{
 
        private $con; 
 
        function __construct(){
 
            require_once dirname(__FILE__).'/DbConnect.php';
 
            $db = new DbConnect();
 
            $this->con = $db->connect();
 
        }
 
        /*CRUD -> C -> CREATE */
 
        public function createUser($name,$email,$password,$mobile,$area){
              
                $stmt = $this->con->prepare("INSERT INTO `user_reg` (`user_id`,`name`, `email`, `password`,`mobile`,`area`) VALUES (NULL,?,?,?,?,?);");
                $stmt->bind_param("sssss",$name,$email,$password,$mobile,$area);
 
                if($stmt->execute()){
                    return 1; 
                }else{
                    return 2; 
                }
              
            }

             public function createDriver($name,$email,$password,$mobile,$area,$driving_lic,$aadhar){
              
                $stmt = $this->con->prepare("INSERT INTO `driver_reg`(`id`, `name`, `email`, `password`, `mobile`, `area`, `driving_lic`, `aadhar`) VALUES (NULL,?,?,?,?,?,?,?);");
                $stmt->bind_param("sssssss",$name,$email,$password,$mobile,$area,$driving_lic,$aadhar);
 
                if($stmt->execute()){
                    return 3; 
                }else{
                    return 4; 
                }
              
            }

           
            public function userLogin($email, $password){
        
            $stmt = $this->con->prepare("SELECT user_id FROM 
                 user_reg WHERE email = ? AND password = ?");
            $stmt->bind_param("ss",$email,$password);
            $stmt->execute();
            $stmt->store_result(); 
            return $stmt->num_rows > 0; 
        }

         public function getUserByUsername($email){
            $stmt = $this->con->prepare("SELECT * FROM 
                user_reg WHERE email = ?");
            $stmt->bind_param("s",$email);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }

        public function matchOTP($rand_no){
        
            $stmt = $this->con->prepare("SELECT `id` FROM `generate_otp` WHERE rand_no = ? ");
            $stmt->bind_param("s",$rand_no);
            $stmt->execute();
            $stmt->store_result(); 
            return $stmt->num_rows > 0; 
        }

         public function getMatchOTPMsg($rand_no){
            $stmt = $this->con->prepare("SELECT * FROM `generate_otp` WHERE rand_no = ?");
            $stmt->bind_param("s",$rand_no);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }

        public function driverLogin($email, $password){
        
            $stmt = $this->con->prepare("SELECT id FROM 
                 driver_reg WHERE email = ? AND password = ?");
            $stmt->bind_param("ss",$email,$password);
            $stmt->execute();
            $stmt->store_result(); 
            return $stmt->num_rows > 0; 
        }

         public function getdriverByUsername($email){
            $stmt = $this->con->prepare("SELECT * FROM 
                driver_reg WHERE email = ? AND flag=1");
            $stmt->bind_param("s",$email);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }

         public function getConfirmed($user_email){
        
            $stmt = $this->con->prepare("SELECT id FROM 
                 book_request WHERE user_email = ?");
            $stmt->bind_param("s",$user_email);
            $stmt->execute();
            $stmt->store_result(); 
            return $stmt->num_rows > 0; 
        }

     public function getConfirmedByUser($user_email){
        
           $stmt = $this->con->prepare("SELECT * FROM 
                book_request WHERE user_email = ? AND flag=1");
            $stmt->bind_param("s",$user_email);
            $stmt->execute();
            return $stmt->get_result()->fetch_assoc();
        }

    

    }
        
 
    