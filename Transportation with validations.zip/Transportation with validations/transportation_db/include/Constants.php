<?php 
    define('DB_NAME','transportation_db');
    define('DB_USER','root');
    define('DB_PASSWORD','');
    define('DB_HOST','localhost');

    ?>
